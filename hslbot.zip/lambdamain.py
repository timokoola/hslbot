from __future__ import print_function

import departures

bot_name = "Helsinki bus stops"
bot_gid = "amzn1.echo-sdk-ams.app.371ceaca-67f6-40c7-8600-b61b90d8f5ea"


def lambda_handler(event, context):
    h = departures.HslRequests("tkootkoo",
                               "THNoJGBRNVhryDdsrMV7xCCaNhWMVNwB4JGCdrR")
    stop_param = "1622"
    if event.has_key("request"):
        # card = event["request"]["type"]
        type = event["request"].get("type", "LaunchRequest")
        if type == "LaunchRequest":
            return launch_response()
        elif type == "IntentRequest":
            intent_ = event["request"]["intent"]
            intentname = intent_["name"]
            if intentname == "GetAirportTrains":
                stop_param = "V0531"
            elif intentname == "GetStopInfo":
                slots = intent_["slots"]
                stop = slots["Stop"].get("value", "1000")
                city = slots["City"].get("value", "")
                stop_param = stop

    text, card = h.relative_time(stop_param)

    return response_creator(text, card)


def launch_response():
    text_item = {"type": "PlainText",
                 "text": "Welcome to %s skill. We can tell you departures on Helsinki area bus stops." % bot_name}
    card_item = {"type": "Simple", "title": "Helsinki bus stops",
                 "content": "Helsinki bus stops can tell you next departures on" +
                            " any Helsinki metropolitan area bus stop."}
    reprompt = {
        "outputSpeech": {"text": "Which stop do you want to know about?",
                         "type": "PlainText"}}
    response = {"version": "1.0",
                "response": {"outputSpeech": text_item, "card": card_item},
                "shouldEndSession": False}

    return response


# reprompt": {
#       "outputSpeech": {
#         "type": "PlainText",
#         "text": "Can I help you with anything else?"
#       }
#     },
def response_creator(text, card):
    text_item = {"type": "PlainText", "text": text}
    card_item = {"type": "Simple", "title": "Stop Info", "content": card}
    reprompt = {
        "outputSpeech": {"text": "Which stop do you want to know about?",
                         "type": "PlainText"}}
    response = {"version": "1.0",
                "response": {"outputSpeech": text_item, "card": card_item,
                             "reprompt": reprompt,
                             "shouldEndSession": True}
                }

    return response
